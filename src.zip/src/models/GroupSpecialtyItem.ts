
export interface GroupSpecialtyItem {
    id: string;
    name: string;
    students: number;
}
