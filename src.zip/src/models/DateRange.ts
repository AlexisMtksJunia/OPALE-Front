
export interface DateRange {
    id: string;
    start: string;
    end: string;
}
